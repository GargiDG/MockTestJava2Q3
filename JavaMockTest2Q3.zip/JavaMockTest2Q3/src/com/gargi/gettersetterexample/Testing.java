package com.gargi.gettersetterexample;

public class Testing {

	public static void main(String[] args) {
		 Person person = new Person();

	        // Set values using the setter methods
	        person.setName("Kim Mingyu");
	        person.setAge(25);
	        person.setAddress("South Korea");

	        // Display values using the getter methods
	        System.out.println("Name: " + person.getName());
	        System.out.println("Age: " + person.getAge());
	        System.out.println("Address: " + person.getAddress());
	}

}

   